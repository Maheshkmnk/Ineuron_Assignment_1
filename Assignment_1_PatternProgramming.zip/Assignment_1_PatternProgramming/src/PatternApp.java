import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/*i n e u r o n
 * Expected Output pattern:
  
&&&&&&& &     & &&&&&&& &     & &&&&&&   &&&&&  &     & 
   &    &&    & &       &     & &     & &     & &&    & 
   &    & &   & &       &     & &     & &     & & &   & 
   &    &  &  & &&&&&&& &     & &&&&&&  &     & &  &  & 
   &    &   & & &       &     & & &     &     & &   & & 
   &    &    && &       &     & &   &   &     & &    && 
&&&&&&& &     & &&&&&&&  &&&&&  &     &  &&&&&  &     & 

*/

public class PatternApp {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String name = "Ineuron";
		System.out.println("Note:: Try to enter length and width size more than 5 for better output..:)\n");
		System.out.print("Enter how much width you want for a letter :: ");
		int width = sc.nextInt();
		System.out.print("Enter how much length you want for a letter :: ");
		int length = sc.nextInt();
		System.out.print("Enter the symbol you want to print pattern using that:: ");
		String symbolToPrintPattern = sc.next();

		pattern(width, length, name, symbolToPrintPattern);

		System.out.println("\n\nThank you for using our App....Visit again");
		sc.close();
	}

	public static void pattern(int width, int length, String name, String symbolToPrintPattern) {
		int k = 2;
		for (int i = 0; i < length; i++) {
			int lp1 = length / 2 + 1;
			boolean flag = false;
			System.out.print("\n");

			for (int l = 0; l < name.length(); l++) {
				String letter = Character.toString(name.charAt(l));

				if (letter.equalsIgnoreCase("i")) {
					iPattern(width, length, i, symbolToPrintPattern);
				} else if (letter.equalsIgnoreCase("n")) {
					nPattern(width, length, i, symbolToPrintPattern);
				} else if (letter.equalsIgnoreCase("e")) {
					ePattern(width, length, i, symbolToPrintPattern);
				} else if (letter.equalsIgnoreCase("u")) {
					uPattern(width, length, i, symbolToPrintPattern);
				} else if (letter.equalsIgnoreCase("r")) {
					List<String> list = rPattern(width, length, i, lp1, flag, k, symbolToPrintPattern);
					k = Integer.parseInt(list.get(0));
					flag = Boolean.parseBoolean(list.get(1));
				} else if (letter.equalsIgnoreCase("o")) {
					oPattern(width, length, i, symbolToPrintPattern);
				}
			}
		}

	}

	public static void iPattern(int width, int length, int i, String symbolToPrintPattern) {
		for (int j = 0; j < width; j++) {
			if (i == 0 || i == length - 1) {
				System.out.print(symbolToPrintPattern);
			} else if (j == width / 2) {
				System.out.print(symbolToPrintPattern);
			} else {
				System.out.print(" ");
			}

		}
		System.out.print(" ");
	}

	public static void nPattern(int width, int length, int i, String symbolToPrintPattern) {
		for (int j = 0; j < width; j++) {
			if (j == 0 || j == length - 1) {
				System.out.print(symbolToPrintPattern);
			} else if (i == j) {
				System.out.print(symbolToPrintPattern);
			} else {
				System.out.print(" ");
			}

		}
		System.out.print(" ");
	}

	public static void ePattern(int width, int length, int i, String symbolToPrintPattern) {
		for (int j = 0; j < width; j++) {
			if (i == 0 || i == length / 2 || i == length - 1) {
				System.out.print(symbolToPrintPattern);
			} else if (j == 0) {
				System.out.print(symbolToPrintPattern);
			} else {
				System.out.print(" ");
			}

		}
		System.out.print(" ");
	}

	public static void uPattern(int width, int length, int i, String symbolToPrintPattern) {
		for (int j = 0; j < width; j++) {
			if (i != length - 1 && (j == 0 || j == width - 1)) {
				System.out.print(symbolToPrintPattern);
			} else if (i == length - 1 && (j != 0 && j != width - 1)) {
				System.out.print(symbolToPrintPattern);
			} else {
				System.out.print(" ");
			}
		}
		System.out.print(" ");
	}

	public static void lPattern(int width, int length, int i, String symbolToPrintPattern) {
		for (int j = 0; j < width; j++) {
			if (j == 0) {
				System.out.print(symbolToPrintPattern);
			} else if (i == length - 1 && (j != 0 && j != width - 1)) {
				System.out.print(symbolToPrintPattern);
			} else {
				System.out.print(" ");
			}
		}
		System.out.print(" ");
	}

	public static void oPattern(int width, int length, int i, String symbolToPrintPattern) {
		for (int j = 0; j < width; j++) {
			if ((i == 0 || i == length - 1) && (j != 0 && j != width - 1)) {
				System.out.print(symbolToPrintPattern);
			} else if ((i != 0 && i != length - 1) && (j == 0 || j == width - 1)) {
				System.out.print(symbolToPrintPattern);
			} else {
				System.out.print(" ");
			}

		}
		System.out.print(" ");
	}

	public static void pPattern(int width, int length, int i, int lp1, String symbolToPrintPattern) {
		for (int j = 0; j < width; j++) {
			if (j == 0) {
				System.out.print(symbolToPrintPattern);
			} else if (i < lp1) {
				if ((i == 0 || i == lp1 - 1) && j != width - 1) {
					System.out.print(symbolToPrintPattern);
				} else if ((i != 0 && i != lp1 - 1) && j == width - 1) {
					System.out.print(symbolToPrintPattern);
				} else {
					System.out.print(" ");
				}
			} else {
				System.out.print(" ");
			}

		}
		System.out.print(" ");
	}

	public static List<String> rPattern(int width, int length, int i, int lp1, boolean flag, int k,
			String symbolToPrintPattern) {
		for (int j = 0; j < width; j++) {
			if (j == 0) {
				System.out.print(symbolToPrintPattern);
			} else if (i < lp1) {
				if ((i == 0 || i == lp1 - 1) && j != width - 1) {
					System.out.print(symbolToPrintPattern);
				} else if ((i != 0 && i != lp1 - 1) && j == width - 1) {
					System.out.print(symbolToPrintPattern);
				} else {
					System.out.print(" ");
				}
			} else if (i >= lp1) {
				if (lp1 % 2 == 0 && j % 2 == 0 && j == k && flag == false) {
					System.out.print(symbolToPrintPattern);
					k = k + 2;
					flag = true;
				} else if ((lp1 % 2 != 0 && j % 2 == 0) && j == k && flag == false) {
					System.out.print(symbolToPrintPattern);
					k = k + 2;
					flag = true;
				} else {
					System.out.print(" ");
				}
			} else {
				System.out.print(" ");
			}

		}
		System.out.print(" ");
		return Arrays.asList(Integer.toString(k), Boolean.toString(flag));
	}

}
