import java.util.Scanner;

/*
 * Expected Output pattern:

#                         #	
# #                     # #	
# # #                 # # #	
# # # #             # # # #	
# # # # #         # # # # #	
# # # # # #     # # # # # #	
# # # # # # # # # # # # # #	
# # # # # # # # # # # # # #

*/

public class PatternApp4 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Note:: Try to enter length size less than width size for better output..:)\n");
		
		System.out.print("Enter how much width you want for a letter :: ");
		int width = sc.nextInt();
		
		System.out.print("\nEnter how much length size you want to print :: ");
		int length = sc.nextInt();
		
		System.out.print("\nEnter the symbol you want to print patter using that:: ");
		String symbolToPrintPattern = sc.next();

		System.out.println();
		
		int min = 0;
		int max = width-1;

		for (int i = 0; i < length; i++) {

			if (i <= length - 2) {
				min += 1;
				max -= 1;
			}

			System.out.println("\t");
			for (int j = 0; j < width; j++) {

				if (i > length - 2 || j == 0 || j == width - 1) {
					System.out.print(" "+symbolToPrintPattern);
				} else if (i <= length - 2 && j != 0 && j != width - 1) {

					if (min <= j && j <= max) {
						System.out.print("  ");
					} else {
						System.out.print(" "+symbolToPrintPattern);
					}

				} else {
					System.out.print("  ");
				}
			}

		}
		
		System.out.println("\n\nThank you for using our App....Visit again");
		sc.close();
	}
}
