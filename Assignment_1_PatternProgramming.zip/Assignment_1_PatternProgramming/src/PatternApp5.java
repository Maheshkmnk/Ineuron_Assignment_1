import java.util.Scanner;
/*
 *Expected Output pattern: 

* * * * * * * * * * *	
* * * * *                  	
* * * *                     	
* * *                        	
* *                           	
*                              	
* *                           	
* * *                        	
* * * *                     	
* * * * *                  	
* * * * * * * * * * *

*/


public class PatternApp5 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.print("Note:: Try to enter pattern size more than 10 for better output..:)\n");

		System.out.print("\nEnter how much pattern size you want to print :: ");
		int n = sc.nextInt();

		System.out.print("\nEnter the symbol you want to print patter using that::");
		String symbolToPrintPattern = sc.next();

		System.out.println();

		int min = (n - 2) / 2 + 1;
		int max = (n - 2) / 2 + 1;

		for (int i = 0; i < n; i++) {
			boolean flag = false;
			System.out.println("\t");
			for (int j = 0; j < n; j++) {

				if (i == 0 || i == n - 1 || j == 0 ) {
					System.out.print(" " + symbolToPrintPattern);

				} else if (j > 0 && j < n / 2 + 1 && i > 0 && i < n - 1) {
					if (min <= j && j <= max) {

						if (i >= (n - 2) / 2 + 1) {
							System.out.print("   ");
							if (flag == false) {
								min += 1;
								max -= 1;
								flag = true;
							}
						} else {
							System.out.print("   ");

							if (flag == false) {
								min -= 1;
								max += 1;
								flag = true;
							}
						}

					} else {
						System.out.print(" " + symbolToPrintPattern);
					}
				} else {
					System.out.print("   ");
				}
			}

		}
		System.out.println("\n\nThank you for using our App....Visit again");
		sc.close();
	}
}
